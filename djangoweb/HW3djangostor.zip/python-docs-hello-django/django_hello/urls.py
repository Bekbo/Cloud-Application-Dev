from django.contrib import admin
from django.urls import path, include
#path('admin/', admin.site.urls),
from django.conf.urls.static import static
urlpatterns = [    
    path('', include('hello.urls')),
    path('admin/', admin.site.urls),
]
