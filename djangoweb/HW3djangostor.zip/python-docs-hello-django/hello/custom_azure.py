from storages.backends.azure_storage import AzureStorage

class PublicAzureStorage(AzureStorage):
    account_name = 'djangostorageacc'
    account_key = 'GJ1LsKmyQWbTJC6l4hblXCv7wSVKkEPFzUI1KrmKHzBTJAhlk+zzii9jba8ntZPluIyj2J/h62Wcpqfa/GiYIg=='
    azure_container = 'images'
    expiration_secs = None