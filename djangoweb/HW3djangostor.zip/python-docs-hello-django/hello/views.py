# from azure.storage.blob.blockblobservice import BlockBlobService
from django.http import HttpResponse
from django.shortcuts import render
import io
from django.views.decorators.csrf import csrf_exempt
from .forms import UploadFileForm
# from .models import Image
# from azure.storage.blob import BlockBlobService, PublicAccess,ContentSettings
from azure.storage.blob import ContainerClient
from azure.storage.blob import BlobServiceClient
import PIL.Image as Image
import uuid

# def upload_blod(request):
#     blob_service = BlockBlobService(account_name="djangostorageacc",account_key="GJ1LsKmyQWbTJC6l4hblXCv7wSVKkEPFzUI1KrmKHzBTJAhlk+zzii9jba8ntZPluIyj2J/h62Wcpqfa/GiYIg==", sas_token = "sp=r&st=2021-03-04T20:50:53Z&se=2021-03-18T20:50:53Z&spr=https&sv=2020-02-10&sr=c&sig=ywXPMtGLLsd3wcddWRY7x%2Fwjb5SBTgAvY1kbo9dEfJs%3D")
#     # blob_name = request.FILES['picture'].name.split('.')[1]
#     blob_name = str(uuid.uuid1())+'.' + request.FILES['picture'].name.split('.')[1]
#     pil_im = Image.open(request.FILES.get('picture'))
#     b = io.BytesIO()
#     pil_im.save(b, 'jpeg')
#     im_bytes = b.getvalue()
#     blob_service.create_blob_from_bytes("images", blob_name,im_bytes)
#     print(blob_service.get_block_list('images', blob_name='sub.jpg').uncommitted_blocks)


def get_images():
    sas = "https://djangostorageacc.blob.core.windows.net/images?sp=rl&st=2021-03-05T15:10:13Z&se=2021-03-18T23:10:13Z&spr=https&sv=2020-02-10&sr=c&sig=3Uk%2B9qpYgr0UlSycfb0G%2BEuWBNtn7KE8VFfCl50SgNo%3D"
    container = ContainerClient.from_container_url(sas)
    blobs = container.list_blobs()
    images_url = []
    for blob in blobs:
        blob = container.get_blob_client(blob.name)
        # print(blob.url + blob.blob_name[-3:])
        images_url.append(blob.url)
    return images_url



@csrf_exempt
def hello(request):
    images = get_images()
    context = {
        'text': 'Hello, Azure!',
        'images': images
    }
    if request.method == 'POST':
        sas = "https://djangostorageacc.blob.core.windows.net/images?sp=racwdl&st=2021-03-05T16:10:32Z&se=2021-03-19T00:10:32Z&spr=https&sv=2020-02-10&sr=c&sig=imFQZZBQYbY%2BXI1C8CEcA7Y82pWRWNKQCBtV4sw5oGo%3D"
        request.FILES.get('picture')
        form = UploadFileForm(request.POST, request.FILES)
        container = ContainerClient.from_container_url(sas)
        blob_name = str(uuid.uuid1())+'.' + request.FILES['picture'].name.split('.')[1]
        pil_im = Image.open(request.FILES.get('picture'))
        b = io.BytesIO()
        pil_im.save(b, 'jpeg')
        im_bytes = b.getvalue()
        container.upload_blob(name=blob_name, data=im_bytes)
        images = get_images()
        context = {
            'text': 'Hello, Azure!',
            'images': images
        }
        return render(request, template_name='index.html', context=context)
    
    return render(request, template_name='images.html', context=context)
